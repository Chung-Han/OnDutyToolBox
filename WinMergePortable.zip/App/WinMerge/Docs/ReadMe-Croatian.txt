WINMERGE

WinMerge je Windows otvoreni program za usporedbu i spajanje. WinMerge mo�e
usporediti i datoteke i mape, prikazuju�i i isti�u�i razlike teksta tako da su
uo�ljive i lako se njima rukuje. WinMerge se mo�e koristiti kao vanjaki alat
ili samostalni program.

WinMerge ima puno vrlo korisnih svojstava koja omogu�uju sinhroniziranje i
spajanje na najjednostavniji mogu�i na�in. Za nekoliko programskih jezika i
tipova datoteka istaknuta je sintaksa.

Najnoviju WinMerge ina�icu i WinMerge obavijesti su dostupna na
https://winmerge.org/.

Quick start
===========
Pokrnuli ste WinMerge, kliknite Pomo� --> Quick start i nau�ite kako koristiti
osnovne mogu�nosti, ili po�ite na Internet i posjetite
https://manual.winmerge.org/QuickStart.html.

WinMerge Pomo�
============= 
WinMerge Pomo� se instalira na disk kao Microsoft HTML Help datoteka, naziva
WinMerge.chm, u mapi WinMerge. Otvara se klikom na Pomo� --> WinMerge Help ili
pritiskom tipke F1 u izborniku programa WinMerge. S komandne linije pokre�e se
naredbom, /? help.

 
Na internetu na https://manual.winmerge.org/ tako�er mo�ete pregledati
WinMerge Help.

WinMerge podr�ka
================
Pitanja i sugestije o WinMerge? Pravo mjesto za to je WinMerge zajedni�ki forum
na https://forums.winmerge.org/. Programeri �esto �itaju i odgovaraju na pitanja.
Koristite Open Discussion forum za op�a WinMerge pitanja, kao npr., pitanja o
kori�tenju. Koristite programerski forum za WinMerge programerska pitanja.

Bugovi i �eljena svojstva
=========================
Kad ne�to primijetite, po�ite na Internet WinMerge forums, odaberite trackers:
na https://project.winmerge.org/, i kliknite �eljeno s izbornika, npr. Bugs ili
Feature Requests, i pregledajte ve� postoje�a javljanja.

Ako �aljete bug, molimo vas navedite broj WinMerge ina�ice koju koristite.
Mo�ete uklju�iti zapis pode�enosti ako kliknete na Pomo�>Pode�enost. Uz
izvje�taj o bugu molimo uklju�ite i zapis pode�enosti; on sadr�i puno korisnih
informacija za nas, programere.


- WinMerge programeri
